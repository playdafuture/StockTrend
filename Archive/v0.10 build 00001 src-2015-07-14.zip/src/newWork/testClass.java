package newWork;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class testClass {
    public static void main(String[] args) throws IOException{
        String fileName = "test.csv";
        DataPointArray testDPA = new DataPointArray();
        try {
            FileReader fr = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fr);
            String fileLine;
            while ((fileLine = br.readLine()) != null) {
                testDPA.insert(fileLine);
            }
        } catch (FileNotFoundException FNFex) {
            System.out.println("ERROR! File not found. Program will exit.");
            System.exit(1);
        }
        System.out.println("File loaded successfully");
        testDPA.reverse();
        baseModel.simulate(testDPA,"testRun");
    }
}
