package newWork;

import java.util.Vector;

public class TradeAnalyzer {
    private Vector<Vector<Trade>> tradeTable;
    private Vector<Double> profitTable;
    
    public TradeAnalyzer() {
        tradeTable = new Vector<Vector<Trade>>();
        profitTable = new Vector<Double>();
    }
    
    public void add(Vector<Trade> VT) {
        tradeTable.add(VT);
    }
    
    public int getSize() {
        return tradeTable.size();
    }
    
    public void calculate() {
        double winRate = 0;
        int wins = 0;
        double instanceProfit, totalProfit = 0;
        int bestIndex = 0, worstIndex = 0;
        profitTable.clear();
        
        for (int i = 0; i < tradeTable.size(); i++) {
            instanceProfit = 0;
            for (int j = 0; j < tradeTable.get(i).size(); j++) {
                instanceProfit += tradeTable.get(i).get(j).percentPL();
            }
            profitTable.add(instanceProfit);
            if (instanceProfit > 0) {
                wins++;
            }
            totalProfit += instanceProfit;
            if (profitTable.get(bestIndex) < instanceProfit) {
                bestIndex = i;
            }
            if (profitTable.get(worstIndex) > instanceProfit) {
                bestIndex = i;
            }
        }
        
        winRate = wins/tradeTable.size();
        System.out.println("Total Profit = " + totalProfit + "%");
        System.out.println("Total Win Rate = " + winRate + "%");
        System.out.println("Best (Winning) is " + tradeTable.get(bestIndex).get(0).getName());
        System.out.println("  with a profit of " + profitTable.get(bestIndex));
        System.out.println("Worst (Losing) is " + tradeTable.get(worstIndex).get(0).getName());
        System.out.println("  with a profit of " + profitTable.get(worstIndex));
    }
}
