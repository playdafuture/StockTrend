package newWork;

import java.util.StringTokenizer;

/**
 * The DataPoint object contains a Date, and the four key values of one day.
 * Open, high, low, close.
 */
public class DataPoint {
    private Date dpDate;
    private double open, high, low, close;
    
    /**
     * Default constructor that sets everything to 0.
     */
    public DataPoint () {
    	dpDate = new Date(0,0,0);
    	open = 0;
    	high = 0;
    	low = 0;
    	close = 0;
    }
    
    /**
     * Constructor that takes in 1 Date object and 4 Doubles.
     * @param initDate Initial Date assignment.
     * @param initOpen Initial Open Value assignment.
     * @param initHigh Initial High Value assignment.
     * @param initLow Initial Low Value assignment.
     * @param initClose Initial Close Value assignment.
     */
    public DataPoint (Date initDate, double initOpen, double initHigh, double initLow, double initClose) {
    	dpDate = initDate;
    	open = initOpen;
    	high = initHigh;
    	low = initLow;
    	close = initClose;
    }
	    
    public Date getDate() { return dpDate;}
    public double getOpen() { return open;}
    public double getHigh() { return high;}
    public double getLow() { return low;}
    public double getClose() { return close;} 
	
    public void setDate (Date newDate) { dpDate = newDate;}	
    public void setOpen (double newOpen) { open = newOpen;}
    public void setHigh (double newHigh) { high = newHigh;}
    public void setLow (double newLow) { low = newLow;}
    public void setClose (double newClose) { close = newClose;}
	    
    /**
     * Print method to print the information of this DataPoint in one line.
     */
    public void print () {
        System.out.println(dpDate.toString() + " " + open + " " + high + 
                " " + low + " " + close);
    }

    /**
     * Converts a String to a DataPoint.
     * @param fileLine "YYYY-MM-DD,Open,High,Low,Close, ..."
     * @return The DataPoint information contained in the line
     */
    public DataPoint convert(String fileLine) {
        DataPoint thisLine = null;
        StringTokenizer token;
        Date date;
        String dateString;
        double open, high, low, close;
        token = new StringTokenizer(fileLine, ",");
        try { //Parse line into DataPoint and add. If fail, skip line and show error.
            dateString = token.nextToken();
            date = new Date(dateString);
            open = Double.parseDouble(token.nextToken());
            high = Double.parseDouble(token.nextToken());
            low = Double.parseDouble(token.nextToken());
            close = Double.parseDouble(token.nextToken());                
            thisLine = new DataPoint(date, open, high, low, close);
        } catch (NumberFormatException NFex) {
            //"Invalid line found"
        }            
        return thisLine;
    }
}
