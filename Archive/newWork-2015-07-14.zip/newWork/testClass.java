package newWork;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class testClass {
    public static void main(String[] args) throws IOException{
        TradeAnalyzer TA = new TradeAnalyzer();
        Vector<String> fileNames = new Vector<String>();
        FileReader fr;
        try {
            fr = new FileReader("index.txt");
            BufferedReader br = new BufferedReader(fr);
            String fileLine;
            while ((fileLine = br.readLine()) != null) {
                fileNames.add(fileLine);
            }
        } catch (FileNotFoundException FNFex) {
            System.out.println("ERROR! Index file not found. Program will exit.");
            System.exit(1);
        }
        System.out.println("File names loaded");
        
        for (int i = 0; i < fileNames.size(); i++) {
            String fileName = fileNames.get(i);
            DataPointArray testDPA = new DataPointArray();
            try {
                fr = new FileReader(fileName);
                BufferedReader br = new BufferedReader(fr);
                String fileLine;
                while ((fileLine = br.readLine()) != null) {
                    testDPA.insert(fileLine);
                }
            } catch (FileNotFoundException FNFex) {
                System.out.println("File not found for " + fileName);
                continue;
            }
            System.out.println("Loaded " + fileName);
            testDPA.reverse();
            Vector<Trade> tempTR;
            tempTR = baseModel.simulate(testDPA,fileName);
            TA.add(tempTR);
        }
        if (TA.getSize() > 0) {
            TA.calculate();
        } else {
            System.out.println("Trade Table is empty.");
        }
    }
}
